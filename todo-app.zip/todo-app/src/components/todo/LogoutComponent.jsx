function LogoutComponent(){
    return (
        <div className='LogoutComponent'>
            <h1>You are Logged out !</h1>
            <div>Thanks you for using our App. Come back soon</div>
        </div>
    )
}

export default LogoutComponent