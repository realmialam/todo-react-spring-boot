import { createContext, useState, useContext } from "react";
import { executeBasicAuthenticationService } from "../api/HelloWorldApiService";
import { apiClient } from "../api/ApiClient";

export const AuthContext = createContext()

export const useAuth = () => useContext(AuthContext)



function AuthProvider({children}){

    const [number, setNumber] = useState(0)
    const [isAuthenticated, setAuthenticated] = useState(false) 
    const [username, setUsername] = useState(null) 
    const [token, setToken] = useState(null)


    // function login(username, password){
    //     if(username === 'realmialam' && password === 'dummy'){
    //        setAuthenticated(true)
    //        setUsername(username)
    //        return true
    //     }else{
    //         setAuthenticated(false)
    //         setUsername(null)
    //         return false;
    //     }
    // }

    async function login(username, password){

        const baToken = 'Basic ' + window.btoa(username + ":" + password)
        // set the token to authContext, so that it can be used by other

        try{

            const response = await executeBasicAuthenticationService(baToken)

            if(response.status == 200){
                setAuthenticated(true)
                setUsername(username)
                setToken(baToken)

                apiClient.interceptors.request.use(
                    (config) => {
                        console.log('intercepting and adding a token')
                        config.headers.Authorization=baToken
                        return config
                    }
                )

                return true
            }else{
                logout()
                return false;
            }
        }catch(error){
            logout()
            return false;
        }
    }

    function logout(){
        setAuthenticated(false)
        setToken(null)
        setUsername(null)
    }

    // setInterval(() => setNumber(number+1), 1000)

    return (
        <AuthContext.Provider value={{number, isAuthenticated, login, logout, username, token}}>
            {children}
        </AuthContext.Provider>
    )
}

export default AuthProvider