function ErrorComponent(){
    return (
        <div className='ErrorComponent'>
            <h1>We are working really hard</h1>
            <div>
                Apologies for 404. Reach out to us as abc.com
            </div>
        </div>
    )
}

export default ErrorComponent